import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Users, CreditCard, Settings, LogOut } from "lucide-react";

const adminNavigation = [
  { name: "Dashboard", href: "/admin", icon: Users },
  { name: "Transactions", href: "/admin/transactions", icon: CreditCard },
  { name: "Settings", href: "/admin/settings", icon: Settings },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, logoutMutation } = useAuth();

  const [, setLocation] = useLocation();
  
  if (!user || user.role !== "admin") {
    setLocation("/auth");
    return null;
  }

  return (
    <div className="flex min-h-screen">
      {/* Admin Sidebar */}
      <div className="w-64 bg-sidebar border-r">
        <div className="flex h-full flex-col">
          <div className="flex-1 flex flex-col gap-y-4 px-4 py-6">
            <div className="font-semibold text-2xl px-2 mb-4">
              TradeX Admin
            </div>
            <nav className="flex flex-1 flex-col gap-y-4">
              {adminNavigation.map((item) => {
                const Icon = item.icon;
                return (
                  <a
                    key={item.name}
                    href={item.href}
                    className="group flex gap-x-3 rounded-md p-2 text-sm leading-6 text-sidebar-foreground hover:bg-sidebar-accent/50"
                  >
                    <Icon className="h-5 w-5 shrink-0" />
                    {item.name}
                  </a>
                );
              })}
            </nav>
            <Button
              variant="ghost"
              className="justify-start gap-x-3"
              onClick={() => logoutMutation.mutate()}
            >
              <LogOut className="h-5 w-5" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 bg-background">
        {children}
      </div>
    </div>
  );
}
